# BTO Recommender System

#### Install necessary libraries ####

```
sudo apt-get install python-clips clips build-essential libssl-dev libffi-dev python-dev python-pip
sudo pip install flask flask-socketio eventlet simplejson pandas
```

#### To run the program ####

```
cd bto-recommender-system/clips
python app.py
```

#### Go to this URL ####
http://127.0.0.1:5000
